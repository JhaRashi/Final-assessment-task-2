package MavenJen.JenkinsPipeline;

public class CalculatorApp {
	
	public int addMethod(int a,int b)
	{
		return(a+b);
	}
	public int subMethod(int a,int b)
	{
		return(a-b);
	}
}
