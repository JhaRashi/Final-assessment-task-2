# Task-6
CI/CD Pipeline with the help of Jenkinsfile and Integrate code, build and test jobs using git code, Maven Build and Selenium Test for a simple application.
